
<!DOCTYPE HTML>

<html>
<head>
<title>Perfect Destination Travelingg Website Template | Friends</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />	
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<style>
	.H3about a{
           color: #fff;
           text-transform: uppercase;
           font-family: 'Roboto', sans-serif;
           margin-bottom: 20px;
       }
       .H3about a:hover {
           color: #005F4D;
       }
</style>
<body>
		<!---start-wrap---->
			<!---start-header---->
			<div class="header">
				<div class="wrap">
				<!---start-logo---->
				<div class="logo">
					<a href="index.html"><img src="images/logo3.png" title="logo" /></a>
				</div>
				<!---End-logo---->
				<!---start-top-nav---->
				<div class="top-nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="Itinerary.php">Itinerary</a></li>
						<li><a href="services.php">Services</a></li>
						<li class="active"><a href="Friends.php">Friends</a></li>
						<li><a 
                    <?php if(!session_id()) session_start();
                    if(isset($_SESSION['user'])){
                    echo "href=personal.php";}
                    else{
                    echo "href=Login.html";
                    }?>>
                    <?php
                    if(isset($_SESSION['user'])){
                    echo "Personal";
                    }
                    else{
                    echo "Login";
                    }
                    ?></a></li>
					</ul>
				</div>
				<div class="clear"> </div>
				<!---End-top-nav---->
			</div>
			<!---End-header---->
		</div>
		<!---End-wrap---->
		<div class="clear"> </div>
		<!---start-content---->
		<div class="banner-section">
		<div class="container">
			<div class="banner-heder">
				<h3>We Plan Your Trip<span>We Find Your Best friend In Your Trip</span></h3>
			</div>
			<div class="banner-grids">
				<div class="col-md-2 banner-grid">
					<form action="Friendscheck.php" method="post">
					<select class="sel" name="Location">
						<option value="null">Location</option>
						<option value="Asia">Asia</option>
						<option value="Europe">Europe</option>
						<option value="Africa">Africa</option>
						<option value="South America">South America</option>
						<option value="North America">North America</option>
						<option value="Oceania">Oceania</option>
					</select>							
				</div>
				<div class="col-md-2 banner-grid">
					<select class="sel" name="Gender">
						<option value="null">Gender</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						
					</select>								
				</div>
				<div class="col-md-2 banner-grid">
					<select class="sel" name="Type">
						<option value=null>Type</option>
						<option value="Group">Group</option>
						<option value="Trip">Trip</option>
					</select>									
				</div>
				<div class="col-md-2 banner-grid">
					<select class="sel" name="Age">
						<option value="null">Age</option>
						<option value="18-25">18-25 </option>
						<option value="26-35">26-35</option>
						<option value="above 36">above 36</option>
						
					</select>									
				</div>
				<div class="col-md-4 search">
					
						<input type="submit" value="Find your friends">
					
				</div></form>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
		<!---End-content---->
		<div class="clear"> </div>
		<!---start-footer---->
		<!---start-footer---->
    <div class="footer">
        <div class="wrap">
            <div class="footer-grids">
                <div class="footer-grid">
                    <h3>EXTRAS</h3>
                    <p>We accept business cooperation on travel.Please see the right for contact information.Cotrip, make travel accessible. </p>
                </div>
                <div class="footer-grid">
                    <h3 class="H3about"><a href="about.html">About us</a> </h3>
                    <ul>
                        <li><a href="#"> Register About Cotrip</a></li>
                        <li><a href="#">Service agreement</a></li>
                        <li><a href="#">Business cooperation </a></li>
                        <li><a href="#">Join us</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Info</h3>
                    <ul>
                        <li><a href="#">Our Company</a></li>
                        <li><a href="#">Recent Info</a></li>
                        <li><a href="#">Cooperation info</a></li>
                        <li><a href="#">Other info</a></li>
                    </ul>
                </div>
               <div class="footer-grid footer-lastgrid">
                    <h3>CONTACT US</h3>
                        <p>Company Information :</p>
                        <p>520, A, Sher street, Wellington, UK</p></br>
                    <div class="footer-grid-address">
                        <p>Tel.123-456-7899</p>
                        <p>Fax: 1234 568</p>
                        <p>Email:<a class="email-link" href="#">info(at)yourcompany.com</a></p>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
    </div>
		<!---End-footer---->
		<div class="clear"> </div>
		<div class="copy-right">
			<p>@ 2020 Cotrip.cn</p>
		</div>
	</body>
</html>

