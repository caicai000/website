<?php 
if(!session_id()) session_start();
?>
<!DOCTYPE HTML>

<html>

<head>
    <title>Perfect Destination Traveling Website Template |Itinerary</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
	<style>
        .text {
            font-size: 30px;
            padding: 25% 33%;
            opacity: 0;
            color: rgb(255, 255, 255);
            text-align: center;
        }
        .img_Australia {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/adly.jpg);
            background-size: 100% 100%;
        }

        .img_Egypt {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/aj.jpg);
            background-size: 100% 100%;
        }

        .img_France {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/bl.jpg);
            background-size: 100% 100%;
        }
        .img_Dubai {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/db.jpg);
            background-size: 100% 100%;
        }
        .img_Canada {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/jnd.jpg);
            background-size: 100% 100%;

        }
        .img_England {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/ld.jpg);
            background-size: 100% 100%;
        }

        .img_Maldif {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/medf.jpg);
            background-size: 100% 100%;
        }
        .img_Milan {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/ml.jpg);
            background-size: 100% 100%;
        }
        .img_Japan {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/jp.jpg);
            background-size: 100% 100%;
        }
        .img_Switzer {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/rs.jpg);
            background-size: 100% 100%;
        }
        .img_Thailand {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/tg.jpg);
            background-size: 100% 100%;
        }
        .img_China {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/zg.jpg);
            background-size: 100% 100%;
        }

        .img_Australia:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Egypt:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_France:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Dubai:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Canada:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }

        .img_England:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Maldif:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Milan:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Japan:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Switzer:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Thailand:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_China:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }

        .text:hover {
            opacity: 1;
        }
        
		.H3about a{
           color: #fff;
           text-transform: uppercase;
           font-family: 'Roboto', sans-serif;
           margin-bottom: 20px;
       }
       .H3about a:hover {
           color: #005F4D;
       }

    </style>
</head>

<body>
    <!---start-header---->
    <div class="header">
        <div class="wrap">
            <div class="logo">
                <a href="index.html"><img src="images/logo3.png" title="logo" /></a>
            </div>
            <div class="top-nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li class="active"><a href="Itinerary.php">Itinerary</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="Friends.php">Friends</a></li>
                    <li><a <?php if(isset($_SESSION[ 'user'])){ echo "href=personal.php";} else{ echo "href=Login.html"; }?>>
                    <?php
                    if(isset($_SESSION['user'])){
                    echo "Personal";
                    }
                    else{
                    echo "Login";
                    }
                    ?></a></li>
                </ul>
            </div>
            <div class="clear"> </div>
        </div>
    </div>
    <!---End-header---->
    <!---start-content---->

    
        <div class="about-header">
            <h3>TRAVEL GUIDES</h3>
        </div>

        <div class="container-fluid">
            <div class="container-fluid-wrap">

                <a href="http://www.mytripjournal.com/EuropeanAdventure" style="color:black;">
                    <div class="text-box">

                        <img src="images/eup.jpg" alt="picture" />
                        <h1>
                            A wonderful trip to Europe!
                        </h1>
                        <br/>
                        <p>
                            This is a journey to Europe. You can see how others have taken Europe.
                        </p>
                </div>
                </a>


                <a href="http://www.mytripjournal.com/ParlowChinaTrip" style="color:black;">
                    <div class="text-box">

                        <img src="images/China.jpg" alt="picture" />
                        <h1>
                            The ancient tour in China 
                        </h1><br/>
                        <p>
                           If you want to roam about the places of interest in China, it is suggested that you go for at least two weeks.
                        </p>
                </div>
                </a>


                <a href="https://www.thestar.com/life/travel/2012/03/05/mexico_travel_beyond_the_beaches_lie_a_wealth_of_cultural_treasures.html " style="color:black;">
                    <div class="text-box">

                        <img src="images/mxg.jpg" alt="picture" />
                        <h1>
                            Brazil tour in South America
                        </h1><br/>
                        <p>
                            Mexico, in South America, with beaches and lots of ancient buildings.
                        </p>
                </div>
                </a>



                <a href="https://www.hobotraveler.com/strategies-for-travel/index.php" style="color:black;">
                    <div class="text-box">

                        <img src="images/TREAVEL1.jpg" alt="picture" />
                        <h1>
                            Andy Lee Graham's personal strategy
                        </h1><br/>
                        <p>
                            Andy Lee Graham has made a detailed plan for personal travel.
                        </p>
                    </div>
                </a>

            </div>
            <div class="container-fluid-wrap">

                <a href="https://bucketlistjourney.net/create-the-perfect-travel-itinerary/" style="color:black;">
                    <div class="text-box">

                        <img src="images/TRAVEL2.jpg" alt="picture" />
                        <h1>
                            Make the perfect journey 
                        </h1><br/>
                        <p>
                            It is necessary to make a itinerary plan. This will make a perfect trip for you. 
                        </p>
                    </div>
                </a>

                <a href="https://www.nomadicmatt.com/travel-guides/italy-travel-tips/rome/" style="color:black;">
                    <div class="text-box">

                        <img src="images/Rome.png" alt="picture" />
                        <h1>
                            Modern Roma with the unique history
                        </h1><br/>
                    <p>
                            Rome considered the center of the world for centuries, it’s full of ruins, history, and some delicious food!                        </p>
                    </div>
                </a>

                <a href="https://www.nomadicmatt.com/travel-guides/france-travel-tips/" style="color:black;">
                    <div class="text-box">

                        <img src="images/france.png" alt="picture" />
                        <h1>
                           The romatic life in France
                        </h1><br/>
                          <p>
                            Wine, cheese, the Eiffel Tower, castles, beautiful beaches – France is famous for a lot of things.                       
                        
                         </p>         
                           </div>
                </a>

                <a href="https://www.nomadicmatt.com/travel-guides/spain-travel-tips/" style="color:black;">
                    <div class="text-box">

                        <img src="images/espagne.png" alt="picture" />
                        <h1>
                            The energetic country in Europe 
                        </h1><br/>
                        <p>
                            The land of the siesta, daily life in Spain moves slowly and runs late.
                        </p>
                    </div>
                </a>

            </div>

        </div>
    
    <!--end of itinerary-->
    <!--picture start-->
        <div class="specials">
            <ul class="specials-picture">
            	<a
                                href="https://www.tripadvisor.com/Tourism-g255337-Gold_Coast_Queensland-Vacations.html?fid=b20d7c66-b729-4e39-8844-150d4992a5a0">
                <li>
                    <div class="img_Australia">
                        <div class="text">
                            <p>Australia</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g294200-Egypt-Vacations.html?fid=3a776a6f-dd06-46c0-a1ca-1dce2372857b">
                <li>
                    <div class="img_Egypt">
                        <div class="text">
                            <p>Egypt</p>
                            
                            
                        </div>
                    </div>
                </li>
                
                </a>
                
                <a
                                href="https://www.tripadvisor.com/Tourism-g187147-Paris_Ile_de_France-Vacations.html?fid=dc4ef5d2-e7c8-4642-925d-b74d8b03951e">
                <li>
                    <div class="img_France">
                        <div class="text">
                            <p>France</p>
                            
                           
                        </div>
                    </div>
                </li>
                 </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g295424-Dubai_Emirate_of_Dubai-Vacations.html"> 
                <li>
                    <div class="img_Dubai">
                        <div class="text">
                            <p>Dubai</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g153339-Canada-Vacations.html">
                <li>
                    <div class="img_Canada">
                        <div class="text">
                            <p>Canada</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g186338-London_England-Vacations.html">
                <li>
                    <div class="img_England">
                        <div class="text">
                            <p>England</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
            </ul>
        </div>
        <div class="specials">
            <ul class="specials-picture">
             <a
                                href="https://www.tripadvisor.com/Tourism-g293953-Maldives-Vacations.html">	
            <li>
                    <div class="img_Maldif">
                        <div class="text">
                            <p>Maldif</p>
                           
                            
                        </div>
                    </div>
                </li>
                </a>
                
                 <a
                                href="https://www.tripadvisor.com/Tourism-g187849-Milan_Lombardy-Vacations.html">
                <li>
                    <div class="img_Milan">
                        <div class="text">
                            <p>Milan</p>
                           
                            
                        </div>
                    </div>
                </li>
                </a>
                
                <a
                                href="https://www.tripadvisor.com/Tourism-g294232-Japan-Vacations.html">
                <li>
                    <div class="img_Japan">
                        <div class="text">
                            <p>Japan</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g188045-Switzerland-Vacations.html?fid=32fadf5e-b0bf-4642-9aa9-047881c0917b">
                <li>
                    <div class="img_Switzer">
                        <div class="text">
                            <p>Switzer</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                
                <a href="https://www.tripadvisor.com/Tourism-g293915-Thailand-Vacations.html">
                <li>
                    <div class="img_Thailand">
                        <div class="text">
                        <p>Thailand</p>
                            
                        </div>
                    </div>
                </li>
                 </a>
                 <a href="https://www.tripadvisor.com/Tourism-g294211-China-Vacations.html?fid=">
                <li>
                    <div class="img_China">
                        <div class="text">
                            <p>China</p>
                             
                        </div>
                    </div>
                </li>
                </a>
            </ul>
        </div>
        <!--picture end-->
    <div class="testmonial-grids">
        <a href="index.php">
            <h3>You can go around the world.</h3>
        </a>
    </div>
    
<div class="service-blocks">
        <div class="blocks">
            <div class="titps">
                <img src="images/response.png" />
                <h1>Quick<br/> Response</h1>
                <!--   <p>If you have any questions, please do not hesitate to ask us.
                    </p>-->
            </div>
            <div class="titps">
                <img src="images/service.png" />
                <h1> 7/7<br/> Service</h1>
                <!--  <p>If you need us, we are here 24-hour.
                    </p>-->
            </div>
            <div class="titps">
                <img src="images/refund.png" />
                <h1>Refund <br/>& <br/>Rebook</h1>
                <!--   <p>If your itinerary was changed, please contact us, we will solve it soon.
                    </p> -->
            </div>
        </div>
</div>

    
    <!--picture end-->
    <!---End-content---->
    <div class="clear"> </div>
    <!---start-footer---->
    <!---start-footer---->
    <div class="footer">
        <div class="wrap">
            <div class="footer-grids">
                <div class="footer-grid">
                    <h3>EXTRAS</h3>
                    <p>We accept business cooperation on travel.Please see the right for contact information.Cotrip, make travel accessible. </p>
                </div>
                <div class="footer-grid">
                    <h3 class="H3about"><a href="about.html">About us </a></h3>
                    <ul>
                        <li><a href="#"> Register About Cotrip</a></li>
                        <li><a href="#">Service agreement</a></li>
                        <li><a href="#">Business cooperation </a></li>
                        <li><a href="#">Join us</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Info</h3>
                    <ul>
                        <li><a href="#">Our Company</a></li>
                        <li><a href="#">Recent Info</a></li>
                        <li><a href="#">Cooperation info</a></li>
                        <li><a href="#">Other info</a></li>
                    </ul>
                </div>
                <div class="footer-grid footer-lastgrid">
                    <h3>CONTACT US</h3>
                        <p>Company Information :</p>
                        <p>520, A, Sher street, Wellington, UK</p></br>
                    <div class="footer-grid-address">
                        <p>Tel.123-456-7899</p>
                        <p>Fax: 1234 568</p>
                        <p>Email:<a class="email-link" href="#">info(at)yourcompany.com</a></p>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
    </div>
    <!---End-footer---->
    <div class="clear"> </div>
    <div class="copy-right">
        <p>@ 2020 Cotrip.cn</p>
    </div>
</body>

</html>