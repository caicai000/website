<?php
session_start();
$email = $_SESSION['user']; 
$form_data_name = $_FILES['form_data']['name'];
$form_data_size = $_FILES['form_data']['size'];
$form_data_type = $_FILES['form_data']['type'];
$form_data = $_FILES['form_data']['tmp_name'];

if ($form_data_name != null) {
    $link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club');
    $data = addslashes(fread(fopen($form_data, "r"), filesize($form_data)));
    //echo "mysqlPicture=".$data;
    
    $sql_select="SELECT email FROM ccs_image WHERE email = '$email'";

    $ret = mysqli_query($link,$sql_select);
    $row = mysqli_fetch_array($ret);



if($email == $row['email']){
    $sql_update="UPDATE ccs_image SET bin_data = '$data', filename = '$form_data_name', filesize = '$form_data_size', filetype = '$form_data_type'
    WHERE email = '$email'";
 
    $result = mysqli_query($link,$sql_update);
}
else{
    $sql_insert="INSERT INTO ccs_image (email,bin_data,filename,filesize,filetype)
                  VALUES ('$email','$data','$form_data_name','$form_data_size','$form_data_type')";
    
    $result = mysqli_query($link,$sql_insert);
    
}

    
        
        
    if ($result) {
        echo "<script>alert('Successfully modified！');window.location= 'personal.php';</script>";
    } else {
        echo "<script>alert('Request failed, please try again');window.location= 'personal.php';</script>";
    }
    
}
else{
    echo "<script>alert('Please select a file！');window.location= 'personal.php';</script>";
}
?>