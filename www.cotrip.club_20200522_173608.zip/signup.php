<?php 
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$phonenumber=$_POST['phonenumber'];
$email=$_POST['email'];
$password=$_POST['password'];

$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club'); 

$sql_select="SELECT username FROM userinform WHERE username = '$username'";

$ret = mysqli_query($link,$sql_select);
$row = mysqli_fetch_array($ret);

if($username == $row['username']){
    echo "<script>alert('Username already exists！');window.location= 'signup.html';</script>";
}
else{
    $sql_insert = "INSERT INTO userinform(username,password,firstname,lastname,email,phonenumber) VALUES('$username','$password','$firstname','$lastname','$email','$phonenumber')";
    
    mysqli_query($link,$sql_insert);
    echo "<script>alert('registration success！');window.location= 'Login.html';</script>";
}

mysqli_close($link);

?>