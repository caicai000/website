<?php
$Location=$_POST['Location'];
$Gender=$_POST['Gender'];
$Type=$_POST['Type'];
$Age=$_POST['Age'];

$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club'); 

if(!session_id()) session_start();
    if(isset($_SESSION['user'])){
     }
      else{
    echo "<script>alert('Please Login!');window.location= 'Login.html';</script>";}

if($Location == "null"){
	if($Gender == "null"){
		if($Type == "null"){
			if($Age == "null"){
				echo "<script>alert('At least one!');window.location= 'Friends.php';</script>";
			}
		}
	}
}



function append_where(&$sql, $has_where) {
    $sql .= $has_where ? ' AND ' : ' WHERE ';
    return $sql;
}


    $sql = "SELECT * FROM `userinform`";
    $has_where = FALSE;
    if($Location != "null") {
        $has_where = append_where($sql, $has_where);
        $sql .= "`Location`='{$Location}'";
    }
    if($Gender != "null") {
        $has_where = append_where($sql, $has_where);
        $sql .= "`Gender`='{$Gender}'";
    }
    if($Type != "null") {
        $has_where = append_where($sql, $has_where);
        $sql .= "`Type`='{$Type}'";
    }
    if($Age != "null") {
        $has_where = append_where($sql, $has_where);
        $sql .= "`Age`='{$Age}'";
    }
    
    $sql .= "ORDER BY RAND() LIMIT 1";
    
    $ret = mysqli_query($link,$sql);

	$row = mysqli_fetch_array($ret);
	
	$email1=$row['email'];
 
	$sql_select_photo = "select bin_data,filetype,filename from ccs_image where email = '$email1'";
	
	$ret1 = mysqli_query($link,$sql_select_photo);
	
	$row1 = mysqli_fetch_array($ret1);
	//if (!$row1) {
	//printf("Error: %s\n", mysqli_error($link));
	//exit();
	//}
	
	$data = $row1['bin_data'];
    $type = $row1['filetype'];
	$name = $row1['filename'];
	
function data_uri($contents, $mime)
{

$base64=base64_encode($contents);

return('data:'.$mime.';base64,'.$base64);
}

if($name == null){
	$src = "images/background.jpg";
}
else{
	$src = data_uri($data,$type);
}
	
mysqli_close($link);
?>

<!DOCTYPE HTML>

<html>
<head>
<title>Perfect Destination Travelingg Website Template | Friends</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />	
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<style>
    .windows{
        background: white;
        width: 50%;
        height: 50%;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        position: absolute;
        margin: auto;
        border-radius: 20px;
  
    }    
    
    .touxiang{
        position: absolute;
        margin: auto;
        top: 20%;
        left: 5%;
        width: 300px;
        height: 300px;
    }
    .firstname{
        margin: auto;
        position: absolute;
        top: 15%;
        left: 40%;
        
    }
    .lasttname{
        margin: auto;
        position: absolute;
        top: 15%;
        left: 70%;
        
    }
    .Email{
        margin: auto;
        position: absolute;
        top: 35%;
        left: 40%;
        
    }
    .phonenumber{
        margin: auto;
        position: absolute;
        top: 35%;
        left: 70%;
        
    }
    .Location{
        margin: auto;
        position: absolute;
        top: 55%;
        left: 40%;
        
    }
    .Gender{
        margin: auto;
        position: absolute;
        top: 55%;
        left: 70%;
        
    }
    .Type{
        margin: auto;
        position: absolute;
        top: 75%;
        left: 40%;
        
    }
    .Age{
        margin: auto;
        position: absolute;
        top: 75%;
        left: 70%;
        
    }
    .textfont{
        text-transform: uppercase;
        font-size: 1.5em;
    }
    .windows span{
        border-radius: 5px;
        border:1px solid #808080;
        display: block;
        width: 250px;
        height: 20px;
        font-size: 1em;
        
    }
    .Congratulations{
        font-size: 2.5em;
        text-transform: uppercase;
    }

    .back{
        position: absolute;
        margin: auto;
        left: 35%;
        right: 35%;
        bottom: 5%;
        height: 30px;
        width: 100px;
        background: #012231;
        color: white;
       
    }
    .back:hover{
        background:#009175; 
    }
</style>

<body>
		<!---start-wrap---->
			<!---start-header---->
			<div class="header">
				<div class="wrap">
				<!---start-logo---->
				<div class="logo">
					<a href="index.html"><img src="images/logo3.png" title="logo" /></a>
				</div>
				<!---End-logo---->
				<!---start-top-nav---->
				<div class="top-nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="Itinerary.php">Itinerary</a></li>
						<li><a href="services.php">Services</a></li>
						<li class="active"><a href="Friends.php">Friends</a></li>
						<li><a 
                    <?php if(!session_id()) session_start();
                    if(isset($_SESSION['user'])){
                    echo "href=personal.php";}
                    else{
                    echo "href=Login.html";
                    }?>>
                    <?php
                    if(isset($_SESSION['user'])){
                    echo "Personal";
                    }
                    else{
                    echo "Login";
                    }
                    ?></a></li>
					</ul>
				</div>
				<div class="clear"> </div>
				<!---End-top-nav---->
			</div>
			<!---End-header---->
		</div>
		<!---End-wrap---->
		<div class="clear"> </div>
		<!---start-content---->
		<div class="banner-section">
		<div class="container">
		
		    
			<div class="windows">
            <div class="Congratulations">
		        <h1>Congratulations!</h1>
		    </div>
			    <div class="touxiang">
			        <img 
			        src="<?php echo $src;?>"
			        >
			    </div>

			    <div class="firstname">
			        <h1 class="textfont">First name</h1>
                    <span><?php echo $row['firstname'];?></span>
			    </div>
			    <div class="lasttname">
			        <h1 class="textfont">last name</h1>
                    <span><?php echo $row['lastname'];?></span>
			    </div>
			    <div class="Email">
			        <h1 class="textfont">e-mail</h1>
                    <span><?php echo $row['email'];?></span>
			    </div>
			    <div class="phonenumber">
			        <h1 class="textfont">phonenumber</h1>
                    <span><?php echo $row['phonenumber'];?></span>
			    </div>
			    <div class="Location">
			        <h1 class="textfont">Location</h1>
                    <span><?php echo $row['location'];?></span>
			    </div>
			    <div class="Gender">
			        <h1 class="textfont">Gender</h1>
                    <span><?php echo $row['gender'];?></span>
			    </div>
			    <div class="Type">
			        <h1 class="textfont">Type</h1>
                    <span><?php echo $row['type'];?></span>
			    </div>
			    <div class="Age">
			        <h1 class="textfont">Age</h1>
                    <span><?php echo $row['age'];?></span>
			    </div>
			     <div ><a href="Friends.php">
			     	 <input type="button" class="back" value="BACK"  />
			     </a>
			       
			    </div>
	   
			</div>
		</div>
	</div>
		<!---End-content---->
		<div class="clear"> </div>
		<!---start-footer---->
		<!---start-footer---->
    <div class="footer">
        <div class="wrap">
            <div class="footer-grids">
                <div class="footer-grid">
                    <h3>EXTRAS</h3>
                    <p>We accept business cooperation on travel.Please see the right for contact information.Cotrip, make travel accessible. </p>
                </div>
                <div class="footer-grid">
                    <h3>About us </h3>
                    <ul>
                        <li><a href="#"> Register About Cotrip</a></li>
                        <li><a href="#">Service agreement</a></li>
                        <li><a href="#">Business cooperation </a></li>
                        <li><a href="#">Join us</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Info</h3>
                    <ul>
                        <li><a href="#">Our Company</a></li>
                        <li><a href="#">Recent Info</a></li>
                        <li><a href="#">Cooperation info</a></li>
                        <li><a href="#">Other info</a></li>
                    </ul>
                </div>
                <div class="footer-grid footer-lastgrid">
                    <h3>CONTACT US</h3>
                        <p>Company Information :</p>
                        <p>520, A, Sher street, Wellington, UK</p></br>
                    <div class="footer-grid-address">
                        <p>Tel.123-456-7899</p>
                        <p>Fax: 1234 568</p>
                        <p>Email:<a class="email-link" href="#">info(at)yourcompany.com</a></p>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
    </div>
		<!---End-footer---->
		<div class="clear"> </div>
		<div class="copy-right">
			<p>@ 2020 Cotrip.cn</p>
		</div>
	</body>
</html>

