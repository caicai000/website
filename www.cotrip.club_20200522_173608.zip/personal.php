<?php

if(!session_id()) session_start();
    if(isset($_SESSION['user'])){
     }
      else{
    echo "<script>alert('Please Login!');window.location= 'Login.html';</script>";}
    
$email = $_SESSION['user'];
$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club'); 

    $sql_select_text = "SELECT * FROM `userinform` WHERE email = '$email' ";

    
    $ret = mysqli_query($link,$sql_select_text);

	$row = mysqli_fetch_array($ret);
	
	$sql_select_photo = "select bin_data,filetype,filename from ccs_image where email = '$email'";
	
	$ret1 = mysqli_query($link,$sql_select_photo);
	
	$row1 = mysqli_fetch_array($ret1);
	
	$data = $row1['bin_data'];
    $type = $row1['filetype'];
	$name = $row1['filename'];
	mysqli_close($link);
	


?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Perfect Destination Traveling Website Template | Contact</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <style>
        .Profile{
            width: 450px;
            height: 200px;
            position: relative;
            left: -10px;
            
        }
        .input{
            width: 350px;
        }
        
        .username{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
            
        }
        .firstname{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .lastname{
            
            
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
            
        }
        .Email{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .phonenumber{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }.Location{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .Gender{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .Type{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .Age{
            margin-top: 25px;
            text-transform: uppercase;
            font-size: 1em; 
        }
        .select1{
            width: 350px;
        }
        .sbutton{
            
        }
        .sbutton:hover{
            background: #009175;
        }
        
        .posi{
           
           
        }
        .touxiang{
            z-index: 99;
            margin-left: 300px;
        }
        .tips{
            
            
        }
        .max{
        	position: absolute;
        	top: 1px;
        }
        .Logout{
            
            margin-left: 290px;
            margin-top: 50px;
        }
        
        .botton_change{
            
            margin-top: 97px;
            margin-left: 290px;
        }
    </style>
    <script type="text/javascript" language="JavaScript">
        function enable(){
            
            document.getElementById('txt2').disabled=false;
            document.getElementById('txt3').disabled=false;
    		document.getElementById('txt4').disabled=false;
            document.getElementById('txt5').disabled=false;
            document.getElementById('txt6').disabled=false;
            document.getElementById('txt7').disabled=false;
            document.getElementById('txt8').disabled=false;
            document.getElementById('txt9').disabled=false;
            document.getElementById('txt10').hidden=false;
            document.getElementById('logout').hidden=true;
            
        }
        function display(){
            document.getElementById('touxiang1').hidden=true;
            document.getElementById('touxiang2').hidden=false;
            document.getElementById('file').hidden=false;
            document.getElementById('tips').hidden=false;
        }
    </script>
</head>

<body>
    <!---start-wrap---->
    <!---start-header---->
    <div class="header">
        <div class="wrap">
            <!---start-logo---->
            <div class="logo">
                <a href="index.html"><img src="images/logo3.png" title="logo" /></a>
            </div>
            <!---End-logo---->
            <!---start-top-nav---->
            <div class="top-nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Itinerary.php">Itinerary</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="Friends.php">Friends</a></li>
                    <li><a 
                    <?php if(!session_id()) session_start();
                    if(isset($_SESSION['user'])){
                    echo "href=#";}
                    else{
                    echo "href=Login.html";
                    }?>>
                    <?php
                    if(isset($_SESSION['user'])){
                    echo "Personal";
                    }
                    else{
                    echo "Login";
                    }
                    ?></a></li>
                </ul>
            </div>
            <div class="clear"> </div>
            <!---End-top-nav---->
        </div>
        <!---End-header---->
    </div>
    <!---End-wrap---->
    <div class="clear"> </div>
    <!---start-content---->
    <div class="content">
        <div class="wrap">
            <!---start-contact---->
            <div class="section group">
                <div class="col span_1_of_3">
                    <div class="contact_info">
                        <h3>My photo</h3>
                        
                        <form method="post" action="uploadphoto.php" name="photo" enctype="multipart/form-data">
                    	
                        <div class="background">
                            <img width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" 
                            src="images/background.jpg"
                            
                            ><br>     
                        </div>
                         <input type="hidden" name="MAX_FILE_SIZE" value="1000000" class="max">
                        <input type="file" name="form_data" id="file" hidden="hidden" accept="image/*" / size="40">
                        <h1 class="tips" hidden="hidden" id="tips">Less than 1m</h1>
                        <input type="button" class="touxiang" value="Modify" onclick="display()" id="touxiang1">
                        <input type="submit" class="touxiang" value="Upload" hidden="hidden" id="touxiang2">
                        </form>
                    </div>  
                </div>
               
                 
                 
                <div class="col span_1_of_3">
                 <h3 >Personal information</h3>
                 <div class="username">
			        <h1 class="textfont">username </h1>
                   <input class="input"  disabled="false" name="username" id="txt4" value="<?php echo $row['username'];?>" >  
			    </div>   
                    
                 <div class="firstname">
			        <h1 class="textfont">First name</h1>
                   <input class="input"  disabled="false" name="firstname" id="txt2" value="<?php echo $row['firstname'];?>" >      
                   </div> 
                    
                  <div class="Email">
			        <h1 class="textfont">e-mail</h1>
                    <input class="input"  readonly="readonly" name="Email"  value="<?php echo $row['email'];?>" >
			    </div>
                   
                  <div class="Location">
			        <h1 class="textfont">Location</h1>
                    <select class="select1" name="Location" disabled="disable" id="txt6" >
						<option value="null" >Location</option>
						<option value="Asia" <?php if($row['location']=="Asia"){ echo 'selected'; }?>>Asia</option>
						<option value="Europe" <?php if($row['location']=="Europe"){ echo 'selected'; }?>>Europe</option>
						<option value="Africa" <?php if($row['location']=="Africa"){ echo 'selected'; }?>>Africa</option>
						<option value="South America" <?php if($row['location']=="South America"){ echo 'selected'; }?>>South America</option>
						<option value="North America" <?php if($row['location']=="North America"){ echo 'selected'; }?>>North America</option>
						<option value="Oceania" <?php if($row['location']=="Oceania"){ echo 'selected'; }?>>Oceania</option>
					</select>
			    </div>
                  
                               <div class="Type">
			        <h1 class="textfont">Type</h1>
                    	<select class="select1" name="Type" disabled="disable" id="txt8" >
						<option value=null>Type</option>
						<option value="Group" <?php if($row['type']=="Group"){ echo "selected"; }?>>Group</option>
						<option value="Trip" <?php if($row['type']=="Trip"){ echo "selected"; }?>>Trip</option>
					</select>	
			    </div> 
                               
                    
                </div>
                      
                       
                       
                <form name='form' method="post" action="personalupdate.php" >          
                <div class="col span_1_of_3">
                    <div class="botton_change">
                        <div class="posi">
                            <input type="button"  value="Change" onclick="enable()">
                        </div>
                    </div>
                   <div class="lastname">
			        <h1 class="textfont">last name</h1>
                    <input class="input"  disabled="disable" name="lastname" id="txt3"  value="<?php echo $row['lastname'];?>">
			    </div> 
                    
               
                    <div class="phonenumber">
			        <h1 class="textfont">phonenumber</h1>
                    <input class="input"  disabled="disable" name="phonenumber" id="txt5"  value="<?php echo $row['phonenumber'];?>">
			    </div>
                    
                    <div class="Gender">
			        <h1 class="textfont">Gender</h1>
                    <select class="select1" name="Gender" disabled="disable" id="txt7" >
						<option value="null">Gender</option>
						<option value="Male" <?php if($row['gender']=="Male"){ echo "selected"; }?>>Male</option>
						<option value="Female" <?php if($row['gender']=="Female"){ echo "selected"; }?>>Female</option>
						
					</select>	
			    </div>
               
               <div class="Age">
			        <h1 class="textfont">Age</h1>
                    	<select class="select1" name="Age" disabled="disable" id="txt9" >
						<option value="null">Age</option>
						<option value="18-25" <?php if($row['age']=="18-25"){ echo "selected"; }?>>18-25 </option>
						<option value="26-35" <?php if($row['age']=="26-35"){ echo "selected"; }?>>26-35</option>
						<option value="above 36" <?php if($row['age']=="above 36"){ echo "selected"; }?>>above 36</option>
						
					</select>	
			    </div>
                   <div class="Logout">
                   <a href="logout.php"><input type="button"  style="text-align: center" value="Logout"  id="logout"></a>
                   </div>
                   </div>      
                    
                       
                       
                        
                        
                        
                        
                        
                        
                        
                </div>
            </div>
        </div>
        <!---End-contact---->
        
        <div style="text-align:center";>
          <input type="submit" class="sbutton" style="text-align: center" value="Submit"  id="txt10" hidden="hidden">
          
          
        </div>
        </form>    
        <div class="clear"> </div>    
       
        
    </div>
    <!---End-content---->
    <div class="clear"> </div>
    <!---start-footer---->
    <div class="footer" style="margin-top: 30px">
        <div class="wrap">
            <div class="footer-grids">
                <div class="footer-grid">
                    <h3>EXTRAS</h3>
                    <p>We accept business cooperation on travel. Please see the right for contact information. Cotrip, make travel accessible.</p>
                </div>
                <div class="footer-grid">
                    <h3>RECENT POSTS</h3>
                    <ul>
                        <li><a href="#">Vestibulum felis</a></li>
                        <li><a href="#">Mauris at tellus</a></li>
                        <li><a href="#">Donec ut lectus</a></li>
                        <li><a href="#">vitae interdum</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>USEFUL INFO</h3>
                    <ul>
                        <li><a href="#">Hendrerit quam</a></li>
                        <li><a href="#">Amet consectetur </a></li>
                        <li><a href="#">Iquam hendrerit</a></li>
                        <li><a href="#">Donec ut lectus </a></li>
                    </ul>
                </div>
                <div class="footer-grid footer-lastgrid">
                    <h3>CONTACT US</h3>
                    <p>Pelleesque conquat dignissim lacus quis altrcies.</p>
                    <div class="footer-grid-address">
                        <p>Tel.800-255-9999</p>
                        <p>Fax: 1234 568</p>
                        <p>Email:<a class="email-link" href="#">info(at)yourcompany.com</a></p>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
    </div>
    <!---End-footer---->
    <div class="clear"> </div>
    <div class="copy-right">
        <p>@ 2020 Cotrip.cn</p>
    </div>
</body>

</html>