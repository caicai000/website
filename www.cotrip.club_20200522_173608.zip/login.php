<?php
$email=$_POST['email'];
$password=$_POST['password'];

$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club'); 

 $sql_select = "SELECT email,password FROM userinform WHERE email = '$email' AND password = '$password'";

 $ret = mysqli_query($link,$sql_select);

 $row = mysqli_fetch_array($ret);

 if($email==$row['email']&&$password==$row['password']){
     setcookie("cotrip", $email, time()+3600);
          
     //开启session
     session_start();
     //创建session
     $_SESSION['user']=$email;
     //写入日志
      $ip = $_SERVER['REMOTE_ADDR'];
     $date = date('Y-m-d H:m:s');
     
      $info = sprintf("Current visiter：%s,IP address：%s,date：%s \n",$email, $ip, $date);
     $sql_logs = "INSERT INTO Logs(email,ip,date) VALUES('$email','$ip','$date')";

     //日志写入文件，如实现此功能，需要创建文件目录logs
            $f = fopen('./logs/'.date('Ymd').'.log','a+');

            fwrite($f,$info);
            fclose($f);

      //跳转到loginsucc.php页面
      echo "<script>alert('Login success!');window.location= 'index.php';</script>";
       
            
        }else {
            //用户名或密码错误，赋值err为1
            echo "<script>alert('Wrong username or password!');window.location= 'Login.html';</script>";
        }

        //关闭数据库
            mysqli_close($link);


?>
