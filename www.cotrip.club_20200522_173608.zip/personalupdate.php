<?php 
session_start();

$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$phonenumber=$_POST['phonenumber'];
$email = $_SESSION['user'];
$profile=$_POST['profile'];
$Location=$_POST['Location'];
$Gender=$_POST['Gender'];
$Type=$_POST['Type'];
$Age=$_POST['Age'];



$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club');     


$sql_update="UPDATE userinform SET firstname = '$firstname', lastname = '$lastname', username = '$username', phonenumber = '$phonenumber', profile = '$profile', 
location = '$Location', gender = '$Gender' , type = '$Type', age = '$Age' WHERE email = '$email'";
 

mysqli_query($link,$sql_update);
echo "<script>alert('Successfully modified！');window.location= 'personal.php';</script>";
mysqli_close($link);

?>