<?php
session_start();
$email = $_SESSION['user'];
$link = mysqli_connect('localhost','www_cotrip_club','yThzMc4ykhHwDnXD','www_cotrip_club'); 

	$sql_select_photo = "select bin_data,filetype,filename from ccs_image where email = '$email'";
	
	$ret1 = mysqli_query($link,$sql_select_photo);
	
	$row1 = mysqli_fetch_array($ret1);
	
	$data = $row1['bin_data'];
    $type = $row1['filetype'];
	$name = $row1['filename'];

    



	mysqli_close($link);
	
	Header( "Content-type: $type");
    echo $data;

?>