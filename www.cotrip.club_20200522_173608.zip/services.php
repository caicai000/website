<?php 
if(!session_id()) session_start();
?>
<!DOCTYPE HTML>

<html>
<head>
<title>Perfect Destination Traveling Website Template | Services</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
<style>
        .text_picture {
            font-size: 30px;
            padding: 25% 33%;
            opacity: 0;
            color: rgb(255, 255, 255);
            text-align: center;
        }
        .img_Australia {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/adly.jpg);
            background-size: 100% 100%;
        }

        .img_Egypt {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/aj.jpg);
            background-size: 100% 100%;
        }

        .img_France {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/bl.jpg);
            background-size: 100% 100%;
        }
        .img_Dubai {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/db.jpg);
            background-size: 100% 100%;
        }
        .img_Canada {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/jnd.jpg);
            background-size: 100% 100%;

        }
        .img_England {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/ld.jpg);
            background-size: 100% 100%;
        }

        .img_Maldif {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/medf.jpg);
            background-size: 100% 100%;
        }
        .img_Milan {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/ml.jpg);
            background-size: 100% 100%;
        }
        .img_Japan {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/jp.jpg);
            background-size: 100% 100%;
        }
        .img_Switzer {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/rs.jpg);
            background-size: 100% 100%;
        }
        .img_Thailand {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/tg.jpg);
            background-size: 100% 100%;
        }
        .img_China {
            position: relative;
            display: block;
            width: 320px;
            height: 200px;
            background-image: url(images/zg.jpg);
            background-size: 100% 100%;
        }

        .img_Australia:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Egypt:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_France:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Dubai:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Canada:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }

        .img_England:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Maldif:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Milan:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Japan:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Switzer:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_Thailand:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }
        .img_China:hover {
            -webkit-filter: opacity(30%);
            filter: opacity(30%);
        }

        .text_picture:hover {
            opacity: 1;
        }
        .H3about a{
           color: #fff;
           text-transform: uppercase;
           font-family: 'Roboto', sans-serif;
           margin-bottom: 20px;
       }
       .H3about a:hover {
           color: #005F4D;
       }
    </style>
</head>
<body>
		<!---start-header---->
			<div class="header">
				<div class="wrap">
				<div class="logo">
					<a href="index.html"><img src="images/logo3.png" title="logo" /></a>
				</div>
				<div class="top-nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="Itinerary.php">Itinerary</a></li>
						<li class="active"><a href="services.php">Services</a></li>
						<li><a href="Friends.php">Friends</a></li>
						<li><a 
						<?php 
                    if(isset($_SESSION['user'])){
                    echo "href=personal.php";}
                    else{
                    echo "href=Login.html";
                    }?>>
                    <?php
                    if(isset($_SESSION['user'])){
                    echo "Personal";
                    }
                    else{
                    echo "Login";
                    }
                    ?></a></li>
					</ul>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
			<!---End-header---->
		<div class="content">
				<!---start-services---->
				<div class="services">
					<div class="wrap">
					  <div class="services-header">
						<h3>Services</h3>
					 </div>
					   <div class="section group group">
							<div class="listview_1_of_2 images_1_of_2">
								<div class="listimg listimg_2_of_1">
									  <img src="images/res.png">
								</div>
							    <div class="text list_2_of_1">
									<h3><span>Travel</span> Resources</h3>
									<h4>There are all kinds of tourism resources .</h4>
									<p>Tourism resources mainly include natural landscape tourism resources and human landscape tourism resources. We provide a variety of tourist attractions for your reference and reading, and introduce local humanities in tourist attractions. </p>
									 <a class="button" href="https://www.triphobo.com/tripplans">Learn More</a>
							   </div>
						   </div>			
							<div class="listview_1_of_2 images_1_of_2">
								<div class="listimg listimg_2_of_1">
									  <img src="images/guid.png">
								</div>
								<div class="text list_2_of_1">
									  <h3><span>Access</span> Guides</h3>
									  <h4>Our company provides quality travel guidance .</h4>
									 		<p>Our website provides tourist information such as tourist attractions, tourist routes, tourist announcements, tourist weather, etc. At the same time, it allows you to understand travel knowledge such as first aid for travel. </p>
									  <a class="button" href="https://www.guidancetvl.com">Learn More</a>
								</div>
							</div>
						</div>
						<div class="section group">
							<div class="listview_1_of_2 images_1_of_2">
								<div class="listimg listimg_2_of_1">
									  <img src="images/air.png">
								</div>
							    <div class="text list_2_of_1 ">
									<h3><span>Airline</span> Travels</h3>
									<h4>Our company customizes the travel route suitable for you .</h4>
									   <p>Air ticket service provides users with real-time flight information query, online booking of air tickets, insurance purchase, online payment, selection of seats and so on. </p>
									 <a class="button" href="https://us.trip.com/">Learn More</a>
							   </div>
						   </div>			
							<div class="listview_1_of_2 images_1_of_2">
								<div class="listimg listimg_2_of_1">
									  <img src="images/compin.png">
								</div>
								<div class="text list_2_of_1">
									  <h3><span>Travel </span>Companions</h3>
									  <h4>A companion in travel is always necessary .</h4>
									    <p>Our company provides high-quality friend search services. You can find the customers that best match your location according to your destination. Users can also rate their friends. We sincerely wish you have a happiness trip. </p>
									  <a class="button" href="Friends.php">Learn More</a>
								</div>
							</div>
						</div>
				  </div>
				</div>
				<!---End-services---->
			<!--picture start-->
        <div class="specials">
            <ul class="specials-picture">
            	<a
                                href="https://www.tripadvisor.com/Tourism-g255337-Gold_Coast_Queensland-Vacations.html?fid=b20d7c66-b729-4e39-8844-150d4992a5a0">
                <li>
                    <div class="img_Australia">
                        <div class="text_picture">
                            <p>Australia</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g294200-Egypt-Vacations.html?fid=3a776a6f-dd06-46c0-a1ca-1dce2372857b">
                <li>
                    <div class="img_Egypt">
                        <div class="text_picture">
                            <p>Egypt</p>
                            
                            
                        </div>
                    </div>
                </li>
                
                </a>
                
                <a
                                href="https://www.tripadvisor.com/Tourism-g187147-Paris_Ile_de_France-Vacations.html?fid=dc4ef5d2-e7c8-4642-925d-b74d8b03951e">
                <li>
                    <div class="img_France">
                        <div class="text_picture">
                            <p>France</p>
                            
                           
                        </div>
                    </div>
                </li>
                 </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g295424-Dubai_Emirate_of_Dubai-Vacations.html"> 
                <li>
                    <div class="img_Dubai">
                        <div class="text_picture">
                            <p>Dubai</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g153339-Canada-Vacations.html">
                <li>
                    <div class="img_Canada">
                        <div class="text_picture">
                            <p>Canada</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g186338-London_England-Vacations.html">
                <li>
                    <div class="img_England">
                        <div class="text_picture">
                            <p>England</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
            </ul>
        </div>
        <div class="specials">
            <ul class="specials-picture">
             <a
                                href="https://www.tripadvisor.com/Tourism-g293953-Maldives-Vacations.html">	
            <li>
                    <div class="img_Maldif">
                        <div class="text_picture">
                            <p>Maldif</p>
                           
                            
                        </div>
                    </div>
                </li>
                </a>
                
                 <a
                                href="https://www.tripadvisor.com/Tourism-g187849-Milan_Lombardy-Vacations.html">
                <li>
                    <div class="img_Milan">
                        <div class="text_picture">
                            <p>Milan</p>
                           
                            
                        </div>
                    </div>
                </li>
                </a>
                
                <a
                                href="https://www.tripadvisor.com/Tourism-g294232-Japan-Vacations.html">
                <li>
                    <div class="img_Japan">
                        <div class="text_picture">
                            <p>Japan</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                <a
                                href="https://www.tripadvisor.com/Tourism-g188045-Switzerland-Vacations.html?fid=32fadf5e-b0bf-4642-9aa9-047881c0917b">
                <li>
                    <div class="img_Switzer">
                        <div class="text_picture">
                            <p>Switzer</p>
                            
                            
                        </div>
                    </div>
                </li>
                </a>
                
                <a href="https://www.tripadvisor.com/Tourism-g293915-Thailand-Vacations.html">
                <li>
                    <div class="img_Thailand">
                        <div class="text_picture">
                        <p>Thailand</p>
                            
                        </div>
                    </div>
                </li>
                 </a>
                 <a href="https://www.tripadvisor.com/Tourism-g294211-China-Vacations.html?fid=">
                <li>
                    <div class="img_China">
                        <div class="text_picture">
                            <p>China</p>
                             
                        </div>
                    </div>
                </li>
                </a>
            </ul>
        </div>
        
        <!--picture end-->
		</div>
		<!---End-content---->
		<!---start-footer---->
		<!---start-footer---->
    <div class="footer">
        <div class="wrap">
            <div class="footer-grids">
                <div class="footer-grid">
                    <h3>EXTRAS</h3>
                    <p>We accept business cooperation on travel.Please see the right for contact information.Cotrip, make travel accessible. </p>
                </div>
                <div class="footer-grid">
                    <h3 class="H3about"><a href="about.html">About us</a> </h3>
                    <ul>
                        <li><a href="#"> Register About Cotrip</a></li>
                        <li><a href="#">Service agreement</a></li>
                        <li><a href="#">Business cooperation </a></li>
                        <li><a href="#">Join us</a></li>
                    </ul>
                </div>
                <div class="footer-grid">
                    <h3>Info</h3>
                    <ul>
                        <li><a href="#">Our Company</a></li>
                        <li><a href="#">Recent Info</a></li>
                        <li><a href="#">Cooperation info</a></li>
                        <li><a href="#">Other info</a></li>
                    </ul>
                </div>
               <div class="footer-grid footer-lastgrid">
                    <h3>CONTACT US</h3>
                        <p>Company Information :</p>
                        <p>520, A, Sher street, Wellington, UK</p></br>
                    <div class="footer-grid-address">
                        <p>Tel.123-456-7899</p>
                        <p>Fax: 1234 568</p>
                        <p>Email:<a class="email-link" href="#">info(at)yourcompany.com</a></p>
                    </div>
                </div>
                <div class="clear"> </div>
            </div>
        </div>
    </div>
		<!---End-footer---->
		<div class="clear"> </div>
		<div class="copy-right">
			<p>@ 2020 Cotrip.cn</p>
		</div>
	</body>
</html>

